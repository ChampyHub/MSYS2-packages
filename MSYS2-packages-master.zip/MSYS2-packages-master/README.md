The most complete documentation currently available:

"JuliaLang / julia: Using MSYS2. #3640":
https://github.com/JuliaLang/julia/issues/3640#issuecomment-35830176
